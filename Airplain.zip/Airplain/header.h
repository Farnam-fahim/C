#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


void menu();

void menu() {
	int option = 0;
	printf("************************\n");
	printf("********* MENU *********\n");
	printf("************************\n");
	puts("1:Print Airbus300A First Class seats");
	puts("2:Make a booking at Airbus300A First Class");
	puts("3:Cancel a booking at Airbus300A First Class");
	puts("4:Print Airbus300A Business Class seats");
	puts("5:Make a booking at Airbus300A Business Class");
	puts("6:Cancel a booking at Airbus300A Business Class");
	puts("7:Print Airbus300A Economy Class seats");
	puts("8:Make a booking at Airbus300A Economy Class");
	puts("9:Cancel a booking at Airbus300A Economy Class");
	puts("10:Print Boing 747 First Class First Floor");
	puts("11:Make a booking at Boing 747 First Class First Floor");
	puts("12:Cancel a booking at  Boing 747 First Class First Floor");
	puts("13:Print Boing 747 First Class Second Floor");
	puts("14:Make a booking at Boing 747 First Class Second Floor");
	puts("15:Cancel a booking at  Boing 747 First Class Second Floor");
	puts("16::Print Boing 747 Business Class seats");
	puts("17:Make a booking at Boing 747 Business Class");
	puts("18:Cancel a booking at Boing 747 Business Class");
	puts("19:Print Boing 747 Economy Class seats");
	puts("20:Make a booking at Boing 747 Economy Class");
	puts("21:Cancel a booking at Boing 747 Economy Class");
	puts("22: Exit Program");
	scanf("%d", &option);


	switch (option)
	{
	case 1:

		printf("you choose option 1!!!\n");
		break;
	case 2:
		printf("you choose option 2!!!\n");
		break;
	case 3:
		printf("you choose option 3!!!\n");
		break;
	case 4:
		printf("you choose option 4!!!\n");
		break;
	case 5:
		break;
	case 6:
		break;
	case 7:
		break;
	case 8:
		break;
	case 9:
		break;
	case 10:
		break;
	case 11:
		break;
	case 12:
		break;
	case 13:
		break;
	case 14:
		break;
	case 15:
		break;
	case 16:
		break;
	case 17:
		break;
	case 18:
		break;
	case 19:
		break;
	case 20:
		break;
	case 21:
		break;
	default:
		break;
	}

}