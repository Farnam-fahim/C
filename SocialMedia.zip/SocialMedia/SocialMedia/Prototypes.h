#pragma once
#include "pch.h"
#include <iostream>
#include <vector>
#include <string>

using namespace std;

void menu();
void createProfile(vector <Profile*> &mediaVectors);
void editProfile(vector <Profile*> &mediaVectors);
void deleteProfile(vector <Profile*> &mediaVectors);
void printProfile(vector <Profile*> &mediaVectors);
void sendPM(vector <Profile*> &mediaVectors);
void picSelection(int choice);

