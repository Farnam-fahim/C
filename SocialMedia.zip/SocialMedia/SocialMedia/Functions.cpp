#include "pch.h"
#include <iostream>
#include <vector>
#include <string>

using namespace std;

vector <Profile*> mediaVectors;

void menu() {
	int choice;


	cout << endl
		<< "***********************************\n"
		<< "************Mediagram**************\n"
		<< "***********************************\n"


		<< " 1 - Create Profile\n"
		<< " 2 - Edit\n"
		<< " 3 - Delete Profile\n"
		<< " 4 - Print Profiles\n"
		<< " 5 - Send a message\n"
		<< " 6 - Exit\n";
	cin >> choice;

	switch (choice)
	{
	case 1:
		createProfile(mediaVectors);
		menu();
		break;

	case 2:
		editProfile(mediaVectors);
		menu();
		break;

	case 3:
		deleteProfile(mediaVectors);
		menu();
		break;

	case 4:
		printProfile(mediaVectors);
		menu();
		break;

	case 5:
		sendPM(mediaVectors);
		break;

	case 6:
		exit(0);
		break;

	}
}


void createProfile(vector <Profile*> &mediaVectors) {
	string name, nation, program, city, fpl, bio;
	int age{}, int picSel{};
	Profile * newProfile = new Profile;

	cout << "Enter your name" << endl;
	cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
	getline(cin, name);
	newProfile->setName(name);

	cout << "How old are you" << endl;
	cin >> age;
	newProfile->setAge(age);

	cout << "Where are you from?" << endl;
	cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
	getline(cin, nation);
	newProfile->setNation(nation);

	cout << "What is your Program?" << endl;
	cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
	getline(cin, program);
	newProfile->setProgram(program);

	cout << "Where do you live(City)?" << endl;
	cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
	getline(cin, city);
	newProfile->setCity(city);

	cout << "What is your favorite Programming Language" << endl;
	cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
	getline(cin, fpl);
	newProfile->setFPL(fpl);

	cout << "Describe a little bit more about yourself" << endl;
	cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
	getline(cin, bio);
	newProfile->setBio(bio);

	cout << "For Your profile picture please choose 1 or 2" << endl;
	cin >> picSel;
	newProfile->setPic(picSel);

	mediaVectors.push_back(newProfile);
	cout << "Profile succesfully created! Hope you enjoy Mediagram :)" << endl;

}

void editProfile(vector <Profile*> &mediaVectors) {
	cout << "These are the list of profile that have been created so far. You may need it for editing" << endl;

	string name, nation, program, city, fpl, bio; int age;

	for (size_t i = 0; i < mediaVectors.size(); i++)
	{
		cout << " Profiles: " << i << endl;
		cout << "Name of Profiles: " << (&mediaVectors)->at(i)->getName() << endl;
	}

	int number{};
	cout << " Choose one of the profiles to edit by pressing the profiles number" << endl;
	cin >> number;

	cout << "Enter your name" << endl;
	cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
	getline(cin, name);
	(mediaVectors).at(number)->setName(name);

	cout << "How old are you now" << endl;
	cin >> age;
	(mediaVectors).at(number)->setAge(age);

	cout << "Where are you from?" << endl;
	cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
	getline(cin, nation);
	(mediaVectors).at(number)->setNation(nation);

	cout << "What is your Program at the moment?" << endl;
	cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
	getline(cin, program);
	(mediaVectors).at(number)->setProgram(program);

	cout << "Where do you live(City) now?" << endl;
	cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
	getline(cin, city);
	(mediaVectors).at(number)->setCity(city);

	cout << "What is your new favorite Programming Language" << endl;
	cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
	getline(cin, fpl);
	(mediaVectors).at(number)->setFPL(fpl);

	cout << "Descrie a little bit more about yourself" << endl;
	cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
	getline(cin, bio);
	(mediaVectors).at(number)->setBio(bio);

	cout << "For Your profile picture please choose 1 or 2" << endl;
	cin >> picSel;
	(mediaVectors).at(number)->setPic(picSel);

}

void deleteProfile(vector <Profile*> &mediaVectors) {
	cout << "These are the list of profile that have been created so far. You may need it for editing" << endl;

	string name, nation, program, city, fpl, bio; int age;

	for (size_t i = 0; i < mediaVectors.size(); i++)
	{
		cout << " Profiles: " << i << endl;
		cout << "Name of Profiles: " << (&mediaVectors)->at(i)->getName() << endl;
	}

	int number2{};
	cout << "Enter the profile number that you would like to delete" << endl;
	mediaVectors.erase(mediaVectors.begin() + number2);

	cout << "Profile has been deleted succesfully" << endl;
}

void printProfile(vector <Profile*> &mediaVectors) {
	for (size_t i = 0; i < mediaVectors.size(); i++) {
		cout << "Profile number: " << i << endl;
		cout << "Name: " << (&mediaVectors)->at(i)->getName() << endl;
		cout << "Age: " << (&mediaVectors)->at(i)->getAge() << endl;
		cout << "Nationality: " << (&mediaVectors)->at(i)->getNation() << endl;
		cout << "Program: " << (&mediaVectors)->at(i)->getProgram() << endl;
		cout << "City: " << (&mediaVectors)->at(i)->getCity() << endl;
		cout << "Favourite Programming Language: " << (&mediaVectors)->at(i)->getFPL() << endl;
		cout << "Bio: " << (&mediaVectors)->at(i)->getBio() << endl;

	}
}

void sendPM(vector <Profile*> &mediaVectors) {
	string sender{}, receiver{}, message{};
	cout << "If you want to send a message type your name here" << endl;
	cin >> sender;
	cout << "To who are you trying to send message" << endl;
	cin >> receiver;
	for (size_t i = 0; i < mediaVectors.size(); i++) {
		if (receiver.compare(mediaVectors.at(i)->getName()) == 0) {
			cout << "Write your message here" << endl;
			cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			getline(cin, message);
			ProfilesVector.at(i)->setTest(mediaVectors.at(i)->getTestimonial() + "\nMessage from " + sender + " >> " + message);
			cout << "Your message has been sent succesfully\n" << endl;
			menu(mediaVectors);
		}
	}
	cout << receiver + " We dont have anyone that you typed in our data\n" << endl;
}
}

void picSelection(int choice) {
	if (choice == 1 || choice == 2) {
		switch (choice) {
		case 1:
			charlie();
			break;

		case 2:
			mustache();
			break;
		}
	}