#include "pch.h"
#include <iostream>
#include <vector>
#include <string>

using namespace std;

//Set Student name
void Profile::setName(string name) {

	this->fullName = name;

}

//Get Student name
string Profile::getName() {

	return fullName;

}
//Set age
void Profile::setAge(int age) {

	this->age = age;

}

//Get age
int Profile::getAge() {

	return age;

}

//Set Nationality
void Profile::setNation(string nation) {

	this->nationality = nation;

}

//Get Nationality
string Profile::getNation() {

	return nationality;

}

//Set Program
void Profile::setProgram(string program) {

	this->program = program;

}

//Get Program
string Profile::getProgram() {

	return program;

}

// Set City
void Profile::setCity(string city) {

	this->city = city;

}

//Get City
string Profile::getCity() {

	return city;

}

//Set FPL
void Profile::setFPL(string fpl) {

	this->FPL = fpl;

};

//Get FPL
string Profile::getFPL() {

	return FPL;

}

//Set Bio
void Profile::setBio(string bio) {

	this->bio = bio;

}

//Get Bio
string Profile::getBio() {

	return bio;

}

//Set Pic
void Profile::setPic(int pic) {

	this->pic = pic;
}

//Get Pic
int Profile::getPic() {
	return pic;
}

//Set Test
void Profile::setTest(string test) {

	this->test = test;
}

//Get Test
string Profile::getTest() {
	return test;
}



//Overloaded Constructor
Profile::Profile(string name, int age, string nationality, string program, string city, string fpl, string bio) : fullName{ name }, age{ age }, nationality{ nationality }, program{ program }, city{ city }, FPL{ fpl }, bio{ bio } {
	cout << "Overloaded Constructor activated" << endl;
}


//Delegating Constructor
Profile::Profile() : Profile("Noname", 0, "none", "none", "none", "none", "none") {
	cout << "delegating" << endl;
}


Profile::~Profile()
{
	cout << "Destructor was activated" << endl;
}
