#pragma once
#include "pch.h"
#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Profile
{
private:
	string fullName;
	int age;
	string nationality;
	string program;
	string city;
	string FPL;
	string bio;
	int pic;


public:

	void setName(string name);
		string getName();

	void setAge(int age);
		int getAge();

	void setNation(string nation);
		string getNation();

	void setProgram(string program);
		string getProgram();

	void setCity(string city);
		string getCity();

	void setFPL(string fpl);
		string getFPL();

	void setBio(string bio);
	string getBio();

	void setPic(int pic);
	int getPic();

	void setTest(string test);
	string getTest();


	//Constructor
	Profile();

	//Overloaded Constructor
	Profile(string name, int age, string nationality, string program, string city, string fpl, string bio);

	//Destructor
	~Profile();
};

