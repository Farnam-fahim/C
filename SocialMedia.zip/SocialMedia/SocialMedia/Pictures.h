#pragma once
#include "pch.h"
#include <iostream>
#include <vector>
#include <string>

using namespace std;

void charlie() {
	cout <<     "___ "<< endl;
		cout <<"/   \ "<< endl;
	cout <<   "_\___/_ " << endl;
	cout <<  "'->---<-' "<< endl;
	cout <<    "(^ ^) "<< endl;
	cout <<    "\ # / "<< endl;
	cout << "__ /'-'\ __ "<< endl;
	cout <<"/ \ / '\ /  \ "<< endl;
cout <<   "/ _ / > o     \ "<< endl;
cout <<  "/ > (_o_  <\    \ "<< endl;
cout <<  "\_ / \_/ | \__\\ \ _ "<< endl;
  cout << "\_/  /    \ \_\(_ "<< endl;
cout <<"mb / \) \__ / "<< endl;
cout << "  \    /    /    \\ "<< endl;
cout << "   >   \    \     \\ "<< endl;
cout <<"  __/    /     \ __  \\ "<< endl;
cout <<"(\\_____\_____//  )  \\ "<< endl;
cout << "  \__`___(   )___/__/    \7 "<< endl;
}


void mustache() {
	    cout << ".------\ / -----." << endl;
	cout << "    |       -       |" << endl;
		cout << "|               |" << endl;
		cout << "|               |" << endl;
		cout << "|               |" << endl;
	 cout << "_______________________" << endl;
	 cout << "========== = .========== =" << endl;
	   cout << "/ ~~~~~       ~~~~~\ "<< endl;
	  cout << "/|     |     |\ "<< endl;
	  cout << "W-- - / \  -- -     W" << endl;
	  cout << "\. | o o |         ./" << endl;
	   cout << "|                  |" << endl;
	   cout << "\     #########     /" << endl;
		cout << "\  ## ---- - ##  /" << endl;
		 cout << "\##         ## /" << endl;
		  cout << "\_____v_____ /" << endl;
}